package cn.wch.otaupdate.other;

public class Constant {
    public static final String ADDRESS="address";

    public static final String START="Start";
    public static final String CANCEL="Cancel";
}
