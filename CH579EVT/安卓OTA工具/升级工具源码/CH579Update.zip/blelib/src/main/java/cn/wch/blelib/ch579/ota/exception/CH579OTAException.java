package cn.wch.blelib.ch579.ota.exception;

public class CH579OTAException extends Exception {
    public CH579OTAException(String message) {
        super(message);
    }
}
