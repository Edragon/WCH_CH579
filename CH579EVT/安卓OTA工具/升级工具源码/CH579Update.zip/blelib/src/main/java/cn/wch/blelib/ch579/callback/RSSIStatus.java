package cn.wch.blelib.ch579.callback;

public interface RSSIStatus {

    void onRSSI(int rssi, int status);
}
